﻿using ClickableTransparentOverlay;
using ImGuiNET;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ESP
{
    public class Renderer : Overlay
    {
        //use your screen resolution
        public Vector2 screenSize = new Vector2(2560, 1440);

        // entities copy, using more thread safe methods
        public ConcurrentQueue<Entity> entities = new ConcurrentQueue<Entity>();
        private Entity localPlayer = new Entity();
        private readonly object entityLock = new object();

        private bool enableESP = true; // enables and desiables hack
        private bool enableTeamESP = true; // enables and disables tracking of team players
        private bool enableEnemyESP = true; // enables and disables tracking of enemy players
        private Vector4 enemyColor = new Vector4(1, 0, 0, 1); // default red
        private Vector4 teamColor = new Vector4(0, 1, 0, 1); // default green

        //draw list
        ImDrawListPtr drawList;

        protected override void Render()
        {
            // draw overlay
            DrawOverlay(screenSize);
            drawList = ImGui.GetWindowDrawList();

            // draw sruff
            if (enableESP)
            {
                foreach (var entity in entities)
                {
                    //check if entity on screen
                    if (EntityOnScreen(entity))
                    {
                        //DrawHealthBar(entity);
                        DrawBox(entity);
                        DrawLine(entity);
                    }
                }
            }
        }

        //checking position

        bool EntityOnScreen(Entity entity)
        {
            if (entity.position2D.X > 0 && entity.position2D.X < screenSize.X && entity.position2D.Y > 0 && entity.position2D.Y < screenSize.Y)
            {
                return true;
            }
            return false;
        }

        private void DrawBox(Entity entity)
        {
            // calculate box hight
            float entityHeight = entity.position2D.Y - entity.viewPosition2D.Y;

            //calculate box dimensions
            Vector2 rectTop = new Vector2(entity.viewPosition2D.X - entityHeight / 3, entity.viewPosition2D.Y);

            Vector2 rectBottom = new Vector2(entity.position2D.X + entityHeight / 3, entity.position2D.Y);

            //get correct color
            if (enableEnemyESP || enableTeamESP) //ignores if both are disabled
            {
                Vector4 boxColor = new Vector4(0, 0, 0, 0);

                // get correct color
                if (localPlayer.team == entity.team && enableTeamESP) { boxColor = teamColor; }
                else if (localPlayer.team != entity.team && enableEnemyESP) { boxColor = enemyColor; }

                // draw boxes
                drawList.AddRect(rectTop, rectBottom, ImGui.ColorConvertFloat4ToU32(boxColor));
            }
        }

        private void DrawLine(Entity entity)
        {
            if (enableEnemyESP || enableTeamESP) //ignores if both are disabled
            {
                Vector4 lineColor = new Vector4(0, 0, 0, 0);

                // get correct color
                if (localPlayer.team == entity.team && enableTeamESP) { lineColor = teamColor; }
                else if (localPlayer.team != entity.team && enableEnemyESP) { lineColor = enemyColor; }

                // draw lines
                drawList.AddLine(new Vector2(screenSize.X / 2, screenSize.Y), entity.position2D, ImGui.ColorConvertFloat4ToU32(lineColor));
            }
        }
       


        // transfer entity methods
        public void UpdateEntities(IEnumerable<Entity> newEntities) //update entities
        {
            entities = new ConcurrentQueue<Entity>(newEntities);
        }

        public void UpdateLocalPlayer(Entity newEntity) // update localplayer
        {
            lock (entityLock)
            {
                localPlayer = newEntity;
            }
        }

        public Entity GetLocalPlayer() // get localplayer
        {
            lock (entityLock)
            {
                return localPlayer;
            }
        }


        void DrawOverlay(Vector2 screenSize) // Overlay Window
        {
            ImGui.Begin("overlay", ImGuiWindowFlags.NoDecoration |
                        ImGuiWindowFlags.NoBackground |
                        ImGuiWindowFlags.NoBringToFrontOnFocus |
                        ImGuiWindowFlags.NoMove |
                        ImGuiWindowFlags.NoInputs |
                        ImGuiWindowFlags.NoCollapse |
                        ImGuiWindowFlags.NoScrollbar |
                        ImGuiWindowFlags.NoScrollWithMouse);
        }

        
        // additional methods for altering cheat
        public void EnableESP(bool enable) // turns cheat on and off
        {
            enableESP = enable;
        }
        public void setTeamColor(Vector4 RGBA) // changes color of lines and boxes of team players
        {
            teamColor = RGBA;
        }
        public void setEnemyColor(Vector4 RGBA) // changes color of lines and boxes of enemy players
        {
            enemyColor = RGBA;
        }
        public void EnableEnemyESP(bool enable) // turns on and off enemy player tracking
        {
            enableEnemyESP = enable;
        }
        public void EnableTeamESP(bool enable) // turns on and off team player tracking
        {
            enableTeamESP = enable;
        }

    }
}
