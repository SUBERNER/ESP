﻿using ClickableTransparentOverlay;
using ImGuiNET;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ESP
{
    public class Renderer : Overlay
    {
        //use your screen resolution
        public Vector2 screenSize = new Vector2(2560, 1440);

        // entities copy, using more thread safe methods
        public ConcurrentQueue<Entity> entities = new ConcurrentQueue<Entity>();
        private Entity localPlayer = new Entity();
        private readonly object entityLock = new object();

        private const bool LOCK = false; // locks the hacks attributes form being altered (manually change this variable)
        private bool enableESP = true;
        private bool renderTeam = true; 
        private bool renderEnemy = true;
        private bool renderBlocks = true;
        private bool renderLine = true;
        private Vector4 enemyColor = new Vector4(1, 0, 0, 1); // default red
        private Vector4 teamColor = new Vector4(0, 1, 0, 1); // default green
        private Vector4 hiddenColor = new Vector4(0 ,0 ,0 ,1); //default black
        private Vector4 nameColor = new Vector4(1, 1, 1, 1); //default white
        private Vector4 boneColor = new Vector4(1, 1, 1, 0.8f); //default white
        private float boneThickness = 4;

        //additional settings
        private bool enableVisibility = false;
        private bool renderSkeleton = false;
        private bool renderHealth = false;
        private bool renderName = false;



        //draw list
        ImDrawListPtr drawList;

        protected override void Render()
        {
            if (!LOCK)
            {
                // ImGui menu
                ImGui.Begin("E. S. P. ");
                ImGui.Checkbox("Enable ESP", ref enableESP);
                ImGui.Spacing();
                ImGui.Checkbox("Render Team", ref renderTeam);
                ImGui.Checkbox("Render Enemies", ref renderEnemy);
                ImGui.Spacing();
                ImGui.Checkbox("Render Blocks", ref renderBlocks);
                ImGui.Checkbox("Render Lines", ref renderLine);
                ImGui.Spacing();
                ImGui.Checkbox("Render Health", ref renderHealth);
                ImGui.Checkbox("Check Visibility", ref enableVisibility);
                ImGui.Checkbox("Render Skeletons", ref renderSkeleton);
                ImGui.Checkbox("Render Names", ref renderName);

                ImGui.Spacing();

                // team color
                if (ImGui.CollapsingHeader("Team Color"))
                    ImGui.ColorPicker4("##teamcolor", ref teamColor);

                // enemy color
                if (ImGui.CollapsingHeader("Enemy Color"))
                    ImGui.ColorPicker4("##enemycolor", ref enemyColor);

                // hidden color
                if (ImGui.CollapsingHeader("Hidden Color"))
                    ImGui.ColorPicker4("##hiddencolor", ref hiddenColor);

                // name color
                if (ImGui.CollapsingHeader("Name Color"))
                    ImGui.ColorPicker4("##namecolor", ref nameColor);

                // bone color
                if (ImGui.CollapsingHeader("Bone Color"))
                    ImGui.ColorPicker4("##bonecolor", ref boneColor);
            }

            // draw overlay
            DrawOverlay(screenSize);
            drawList = ImGui.GetWindowDrawList();

            // draw sruff
            if (enableESP)
            {
                foreach (var entity in entities)
                {
                    // check if entity on screen
                    if (EntityOnScreen(entity))
                    {
                        // checks if shoud be drawn on
                        if (localPlayer.team != entity.team && !renderEnemy || localPlayer.team == entity.team && !renderTeam) continue;

                        if (renderHealth) DrawHealthBar(entity);
                        if (renderBlocks) DrawBox(entity);
                        if (renderLine) DrawLine(entity);
                        if (renderName) DrawName(entity);
                        if (renderSkeleton) DrawBones(entity);
                    }
                }
            }
        }

        //checking position

        bool EntityOnScreen(Entity entity)
        {
            if (entity.position2D.X > 0 && entity.position2D.X < screenSize.X && entity.position2D.Y > 0 && entity.position2D.Y < screenSize.Y)
            {
                return true;
            }
            return false;
        }

        // drawing methods
        private void DrawHealthBar(Entity entity)
        {
            // calculate bar height
            float entityHeight = entity.position2D.Y - entity.viewPosition2D.Y;

            // get box location
            float boxLeft = entity.viewPosition2D.X - entityHeight / 3;
            float boxRight = entity.position2D.X + entityHeight / 3;

            // Calculate health bar width
            float barPercentWidth = 0.05f; // 5% or 1/20 of box width
            float barPixelWidth = barPercentWidth * (boxRight - boxLeft);

            // Calculate bar height based on health
            float barHeight = entityHeight * (entity.health / 100f);

            // Calculate bar rectangle corners
            Vector2 barTop = new Vector2(boxLeft - barPixelWidth, entity.position2D.Y - barHeight);
            Vector2 barBottom = new Vector2(boxLeft, entity.position2D.Y);

            //get correct color
            Vector4 barColor = localPlayer.team == entity.team ? enemyColor : teamColor;

            // Draw health bar
            drawList.AddRectFilled(barTop, barBottom, ImGui.ColorConvertFloat4ToU32(barColor));
        }

        private void DrawName(Entity entity, int offset = 20)
        {
            
            Vector2 textLocation = new Vector2(entity.viewPosition2D.X, entity.viewPosition2D.Y - offset); //get location
            drawList.AddText(textLocation, ImGui.ColorConvertFloat4ToU32(nameColor), $"{entity.name}"); // draw on screen
        }

        private void DrawBones(Entity entity)
        {
            // correctly colors bones
            uint uintColor = ImGui.ColorConvertFloat4ToU32(boneColor);

            float currentBoneThickness = boneThickness / entity.distance; // not perfect but something
            // draw lines between bones
            drawList.AddLine(entity.bones2D[1], entity.bones2D[2], uintColor, currentBoneThickness); // neck to head
            drawList.AddLine(entity.bones2D[1], entity.bones2D[3], uintColor, currentBoneThickness); // neck to left shoulder
            drawList.AddLine(entity.bones2D[1], entity.bones2D[6], uintColor, currentBoneThickness); // neck to shoulderRight
            drawList.AddLine(entity.bones2D[3], entity.bones2D[4], uintColor, currentBoneThickness); // shoulderLeft to arm
            drawList.AddLine(entity.bones2D[6], entity.bones2D[7], uintColor, currentBoneThickness); // shoulderRight to arm
            drawList.AddLine(entity.bones2D[4], entity.bones2D[5], uintColor, currentBoneThickness); // armLeft to handLeft
            drawList.AddLine(entity.bones2D[7], entity.bones2D[8], uintColor, currentBoneThickness); // armRight to handRight
            drawList.AddLine(entity.bones2D[1], entity.bones2D[0], uintColor, currentBoneThickness); // neck to waist
            drawList.AddLine(entity.bones2D[0], entity.bones2D[9], uintColor, currentBoneThickness); // waist to kneeLeft
            drawList.AddLine(entity.bones2D[0], entity.bones2D[11], uintColor, currentBoneThickness); // waist to kneeRight
            drawList.AddLine(entity.bones2D[9], entity.bones2D[10], uintColor, currentBoneThickness); // kneeLeft to feetLeft
            drawList.AddLine(entity.bones2D[11], entity.bones2D[12], uintColor, currentBoneThickness); // kneeRight to feetRight
            drawList.AddCircle(entity.bones2D[2], 3 + currentBoneThickness, uintColor); // circle on head
        }

        private void DrawBox(Entity entity)
        {
            // calculate box hight
            float entityHeight = entity.position2D.Y - entity.viewPosition2D.Y;

            //calculate box dimensions
            Vector2 rectTop = new Vector2(entity.viewPosition2D.X - entityHeight / 3, entity.viewPosition2D.Y);

            Vector2 rectBottom = new Vector2(entity.position2D.X + entityHeight / 3, entity.position2D.Y);

            //get correct color
            Vector4 boxColor = localPlayer.team == entity.team ? teamColor : enemyColor;

            // checks if visible or hidden and sets to hiddenColor if not spotted
            if (enableVisibility && localPlayer.team != entity.team) { boxColor = entity.spotted == true ? boxColor : hiddenColor; }


            //draw boxes
            drawList.AddRect(rectTop, rectBottom, ImGui.ColorConvertFloat4ToU32(boxColor));
        }

        private void DrawLine(Entity entity)
        {
            Vector4 lineColor = localPlayer.team == entity.team ? teamColor : enemyColor;

            // draw lines
            drawList.AddLine(new Vector2(screenSize.X / 2, screenSize.Y), entity.position2D, ImGui.ColorConvertFloat4ToU32(lineColor));
        }
       


        // transfer entity methods
        public void UpdateEntities(IEnumerable<Entity> newEntities) //update entities
        {
            entities = new ConcurrentQueue<Entity>(newEntities);
        }

        public void UpdateLocalPlayer(Entity newEntity) // update localplayer
        {
            lock (entityLock)
            {
                localPlayer = newEntity;
            }
        }

        public Entity GetLocalPlayer() // get localplayer
        {
            lock (entityLock)
            {
                return localPlayer;
            }
        }

        void DrawOverlay(Vector2 screenSize) // Overlay Window
        {
            if (!LOCK) 
            {
                ImGui.SetNextWindowSize(screenSize);
                ImGui.SetNextWindowPos(new Vector2(0, 0));
            }
            ImGui.Begin("overlay", ImGuiWindowFlags.NoDecoration |
                        ImGuiWindowFlags.NoBackground |
                        ImGuiWindowFlags.NoBringToFrontOnFocus |
                        ImGuiWindowFlags.NoMove |
                        ImGuiWindowFlags.NoInputs |
                        ImGuiWindowFlags.NoCollapse |
                        ImGuiWindowFlags.NoScrollbar |
                        ImGuiWindowFlags.NoScrollWithMouse);
        }

    }
}
