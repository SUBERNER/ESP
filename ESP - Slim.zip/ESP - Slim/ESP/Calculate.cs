﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ESP
{
    public static class Calculate
    {
        public static Vector2 WorldToScreen(float[] matrix, Vector3 pos, Vector2 windowSize)
        {
            Vector2 offset = new Vector2(0, 0);

            // calculate screenW
            float screenW = (matrix[12] * pos.X ) + (matrix[13] * pos.Y) + (matrix[14] * pos.Z) + matrix[15];

            // if entity is in front of us
            if (screenW > 0.001f)
            {
                // calculate screen X and Y
                float screenX = (matrix[0] * pos.X) + (matrix[1] * pos.Y) + (matrix[2] * pos.Z) + matrix[3];
                float screenY = (matrix[4] * pos.X) + (matrix[5] * pos.Y) + (matrix[6] * pos.Z) + matrix[7];

                // perform perspective division
                float X = (windowSize.X / 2.5f) + (windowSize.X / 2.5f) * screenX / screenW + offset.X;
                float Y = (windowSize.Y / 2.5f) - (windowSize.Y / 2.5f) * screenY / screenW + offset.Y;

                // return coordinates
                return new Vector2(X, Y);
            }
            else
            {
                //return indixative value if out of bounds
                return new Vector2(-99, -99);
            }
        }
    }
}
